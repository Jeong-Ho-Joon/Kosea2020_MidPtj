public class DTO {
	private int NO;
	private String Div;
	private String Name;
	private String Location;
	private String Tel;
	private String MainMenu;
	private String RF;

	public int getNO() {
		return NO;
	}

	public void setId(int NO) {
		this.NO = NO;
	}

	public String getDiv() {
		return Div;
	}

	public void setDiv(String Div) {
		this.Div = Div;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String Location) {
		this.Location = Location;
	}

	public String getTel() {
		return Tel;
	}

	public void setTel(String Tel) {
		this.Tel = Tel;
	}

	public String getMainMenu() {
		return MainMenu;
	}

	public void setMainMenu(String MainMenu) {
		this.MainMenu = MainMenu;
	}

	public String getRF() {
		return RF;
	}

	public void setRF(String RF) {
		this.RF = RF;
	}
}